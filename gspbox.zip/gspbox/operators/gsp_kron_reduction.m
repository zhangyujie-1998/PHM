function Gnew = gsp_kron_reduction( G,ind )
%GSP_KRON_REDUCTION See gsp_kron_reduce

Gnew = gsp_kron_reduce(G,ind);


end

