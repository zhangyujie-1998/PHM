fext='.tex'
urlbase='https://epfl-lts2.github.io/gspbox-html/doc'
urlext='html'
widthstr='60ex'
imagetype='eps'
includeoutput=True