fext='.m'
urlbase='https://epfl-lts2.github.io/gspbox-html/doc'
urlext='.html'
